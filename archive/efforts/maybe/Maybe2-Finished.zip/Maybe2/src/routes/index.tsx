import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { courseFile, COURSES_URL, courseUrl, topics as localTopics, type ShelfTopic } from "../../maybe2/Finished/library";
import { callsNida, nida81 } from "../../maybe2/systemshell/nida81";
import { answerQuiz, closeHelp, go, openHelp, openLesson, pageOf, send } from "../../maybe2/systemshell/shell";
import type { Book, Lesson } from "../../maybe2/systemshell/types";

type CatalogSearch = {
  level: "topic" | "module" | "course";
  topic: number;
  module: number;
};

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): CatalogSearch => ({
    level: search.level === "module" || search.level === "course" ? search.level : "topic",
    topic: Number(search.topic ?? 0) || 0,
    module: Number(search.module ?? 0) || 0,
  }),
  component: Home,
});

type Phase = "catalog" | "splash" | "lesson" | "course" | "directions";
type Level = "topic" | "module" | "course";

function Home() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const [developer, setDeveloper] = useState(false);
  const [missed, setMissed] = useState<string | null>(null);
  const [phase, setPhase] = useState<Phase>("catalog");
  const [book, setBook] = useState<Book | null>(null);
  const [pagesOpen, setPagesOpen] = useState(false);
  const [shelf, setShelf] = useState<ShelfTopic[] | null>(null);
  const page = book ? pageOf(book) : null;

  useEffect(() => {
    let cancel = false;
    fetch(`${COURSES_URL}/catalog.json`)
      .then((response) => {
        if (!response.ok) throw new Error(String(response.status));
        return response.json();
      })
      .then((catalog: { topics?: { title: string; modules: { title: string; courses: { id: string; title: string; file?: string | null }[] }[] }[] }) => {
        if (cancel) return;
        const remote = (catalog.topics ?? []).map((topic) => ({
          title: topic.title,
          modules: topic.modules.map((module) => ({
            title: module.title,
            courses: module.courses.map((course) => ({
              id: course.id,
              title: course.title,
              file: course.file ?? null,
              lesson: localLesson(course.id),
            })),
          })),
        }));
        setShelf(remote.length ? remote : localTopics);
      })
      .catch(() => {
        if (!cancel) setShelf(localTopics);
      });
    return () => {
      cancel = true;
    };
  }, []);

  function objectiveScore(objective: number) {
    if (!book) return 0;
    const questions = book.pages.filter((item) => item.quiz?.scored && item.quiz.objective === objective);
    if (!questions.length) return 0;
    const right = questions.filter((item) =>
      book.session.responses.some((response) => response.pageId === item.id && response.value === "correct"),
    ).length;
    return Math.round((100 * right) / questions.length);
  }

  function shown(label: string, id: string) {
    return developer ? `${label} · ${id}` : label;
  }

  async function chooseLesson(course: { id: string; title: string; lesson: Lesson | null; file?: string | null }, topicTitle: string, moduleTitle: string) {
    const file = courseFile(topicTitle, moduleTitle, course);
    let lesson: Lesson | null = null;
    let translated = false;
    try {
      const response = await fetch(courseUrl(file));
      if (response.ok) {
        const data = (await response.json()) as Lesson;
        if (Array.isArray(data.pages) && data.pages.length) {
          lesson = data;
          translated = true;
        }
      }
    } catch {
      translated = false;
    }
    if (!lesson) {
      lesson = course.lesson ?? localLesson(course.id);
      translated = Boolean(lesson);
    }
    const opened =
      lesson ??
      ({
        id: course.id,
        title: course.title,
        pages: [
          {
            id: "P0",
            text: [course.title, "This course has not been translated yet.", courseUrl(file)],
            jumps: [],
          },
        ],
        menu: [],
      } satisfies Lesson);
    setBook(openLesson(opened));
    setPhase(translated ? "splash" : "lesson");
  }

  function showLibrary() {
    setPhase("catalog");
    navigate({ search: { level: "topic", topic: 0, module: 0 } });
  }

  return (
    <div className="relative min-h-dvh bg-rail text-bar-fg">
      <header className="flex shrink-0 items-center justify-between bg-bar px-5 py-4">
        <p className="font-serif text-xl">Maybe2</p>
        <div className="flex items-center gap-2">
          {developer && book ? (
            <button type="button" className="min-h-11 bg-paper px-3 text-sm text-ink" onClick={() => setPagesOpen((open) => !open)}>
              {phase === "lesson" && page ? page.id : "Pages"}
            </button>
          ) : null}
          {phase !== "catalog" ? (
            <button type="button" className="min-h-11 px-3 text-sm" onClick={showLibrary}>
              Maybe2
            </button>
          ) : null}
          <a className="min-h-11 px-3 text-sm leading-[44px]" href="/Maybe2-Finished.zip" download>
            Download source
          </a>
          <button
            type="button"
            className="min-h-11 px-3 text-sm"
            onClick={() => setDeveloper((on) => !on)}
          >
            {developer ? "Developer on" : "Developer"}
          </button>
        </div>
      </header>
      {pagesOpen && book ? (
        <div className="absolute right-4 top-16 z-20 max-h-[70dvh] w-44 overflow-y-auto border border-line bg-paper p-2 text-ink">
          {book.pages.map((item) => (
            <button
              key={item.id}
              type="button"
              className="block min-h-10 w-full px-2 text-left text-sm"
              onClick={() => {
                setMissed(null);
                setBook(go(book, item.id));
                setPhase("lesson");
                setPagesOpen(false);
              }}
            >
              {item.id}
            </button>
          ))}
        </div>
      ) : null}

      {phase === "catalog" ? (
        shelf ? (
          <Library
            topics={shelf}
            level={search.level}
            topicIndex={search.topic}
            moduleIndex={search.module}
            onCourse={chooseLesson}
          />
        ) : (
          <main className="mx-auto max-w-3xl px-5 py-10">
            <h1 className="font-serif text-4xl text-paper">Loading courses…</h1>
          </main>
        )
      ) : null}

      {phase === "splash" ? (
        <Page
          title="Nida"
          pageId={nida81.splash.id}
          lines={nida81.splash.text}
          actions={[{ label: nida81.splash.continue, run: () => setPhase("lesson") }]}
        />
      ) : null}

      {phase === "lesson" && book && page?.kind === "help" ? (
        <Page
          title={book.title}
          pageId={page.id}
          lines={page.text}
          actions={[{ label: "Back", run: () => setBook(closeHelp(book)) }]}
        />
      ) : null}

      {phase === "lesson" && book && page && page.kind !== "help" ? (
        <Page
          title={book.title}
          pageId={page.id}
          lines={(missed === page.id ? [...page.text, "Try again."] : page.text)
            .map((line) => line.replaceAll("XX%", `${book.score}%`))
            .concat(page.review ? [`Your score is ${book.score}%.`] : [])}
          helpWord={page.help?.word}
          onWord={
            page.help
              ? () => setBook(openHelp(book, page.help!.page))
              : undefined
          }
          actions={[
            ...page.jumps.map((id, index) => ({
              label: shown(page.continue || (index % 2 === 0 ? "Next" : "Back"), id),
              run: () => {
                setMissed(null);
                setBook(go(book, id));
              },
            })),
            ...(page.help
              ? [{ label: "?", run: () => setBook(openHelp(book, page.help!.page)) }]
              : []),
            ...(page.quiz?.choices ?? []).map((choice) => ({
              label: choice.label,
              run: () => {
                if (page.quiz?.scored) {
                  setMissed(null);
                  setBook(answerQuiz(book, choice.correct));
                  return;
                }
                if (choice.correct && page.quiz?.next) {
                  setMissed(null);
                  setBook(go(book, page.quiz.next));
                  return;
                }
                if (!choice.correct) setMissed(page.id);
              },
            })),
            ...(page.review ?? [])
              .filter((item) => objectiveScore(item.objective) < 100)
              .map((item) => ({
                label: shown(item.label, item.page),
                run: () => {
                  setMissed(null);
                  setBook(go(book, item.page));
                },
              })),
            ...(page.items ?? []).map((item) => ({
              label: shown(item.label, item.page),
              run: () => {
                if (item.book && callsNida(item.book)) {
                  setPhase(item.page === "P10020" ? "directions" : "course");
                  return;
                }
                if (item.page === page.id) return;
                setBook(go(book, item.page));
              },
            })),
            ...(page.sends ?? [])
              .filter((name) => name !== "gotoMenuPage")
              .map((name) => ({
                label: name,
                run: () => setBook(send(book, name)),
              })),
            ...(page.outside && callsNida(page.outside.book)
              ? [{ label: page.outside.label, run: () => setPhase("course") }]
              : (page.sends ?? []).includes("gotoMenuPage")
                ? [{ label: "Menu", run: () => setPhase("course") }]
                : []),
          ]}
        />
      ) : null}

      {phase === "directions" ? (
        <Page
          title="Nida"
          pageId={nida81.directions.id}
          lines={nida81.directions.text}
          actions={[{ label: "Back", run: () => setPhase("lesson") }]}
        />
      ) : null}

      {phase === "course" && book ? (
        <Page
          title="Nida"
          pageId={nida81.courseMenu.id}
          lines={["LESSON MENU", book.title]}
          actions={book.menu.map((item) => ({
            label: shown(item.label, item.page),
            run: () => {
              setBook(go(book, item.page));
              setPhase("lesson");
            },
          })).concat([{ label: "Lesson Exit", run: () => setPhase("catalog") }])}
        />
      ) : null}
    </div>
  );
}

function localLesson(id: string): Lesson | null {
  const wanted = id.toLowerCase();
  for (const topic of localTopics) {
    for (const module of topic.modules) {
      const hit = module.courses.find((course) => course.id.toLowerCase() === wanted);
      if (hit?.lesson) return hit.lesson;
    }
  }
  return null;
}

function Library({
  topics,
  level,
  topicIndex,
  moduleIndex,
  onCourse,
}: {
  topics: ShelfTopic[];
  level: Level;
  topicIndex: number;
  moduleIndex: number;
  onCourse: (
    course: { id: string; title: string; lesson: Lesson | null; file?: string | null },
    topicTitle: string,
    moduleTitle: string,
  ) => void;
}) {
  const topic = topics[topicIndex] ?? topics[0];
  const module = topic?.modules[moduleIndex] ?? topic?.modules[0];
  const heading = level === "topic" ? "Main Topic" : level === "module" ? topic.title : module.title;
  const rows =
    level === "topic"
      ? topics.map((item, index) => ({
          key: item.title,
          label: item.title,
          search: { level: "module" as const, topic: index, module: 0 },
          course: null,
        }))
      : level === "module"
        ? [
            {
              key: "back",
              label: "Main Topics",
              search: { level: "topic" as const, topic: 0, module: 0 },
              course: null,
            },
            ...topic.modules.map((item, index) => ({
              key: `${index}-${item.title}`,
              label: item.title,
              search: { level: "course" as const, topic: topicIndex, module: index },
              course: null,
            })),
          ]
        : [
            {
              key: "back",
              label: topic.title,
              search: { level: "module" as const, topic: topicIndex, module: 0 },
              course: null,
            },
            ...module.courses.map((item) => ({
              key: item.id || item.title,
              label: item.title,
              search: null,
              course: item,
            })),
          ];

  return (
    <main className="mx-auto w-full max-w-3xl px-5 py-10">
      <p className="text-sm tracking-wide text-paper/70">Maybe2</p>
      <h1 className="font-serif text-4xl text-paper">{heading}</h1>
      <ul className="mt-8 flex flex-col gap-3">
        {rows.map((row) => (
          <li key={row.key}>
            {row.search ? (
              <Link
                to="/"
                search={row.search}
                className="block min-h-16 w-full cursor-pointer bg-paper px-5 py-4 text-left font-serif text-2xl text-ink"
              >
                {row.label}
              </Link>
            ) : (
              <button
                type="button"
                className="min-h-16 w-full bg-paper px-5 text-left font-serif text-2xl text-ink"
                onClick={() => {
                  if (row.course) onCourse(row.course, topic.title, module.title);
                }}
              >
                {row.label}
              </button>
            )}
          </li>
        ))}
      </ul>
    </main>
  );
}

function Page({
  title,
  pageId,
  lines,
  actions,
  helpWord,
  onWord,
}: {
  title: string;
  pageId: string;
  lines: string[];
  actions: { label: string; run: () => void }[];
  helpWord?: string;
  onWord?: () => void;
}) {
  const name = (label: string) => label.split(" · ")[0];
  const back = actions.find((action) => name(action.label) === "Back");
  const next = actions.find((action) => name(action.label) === "Next");
  const rest = actions.filter((action) => action !== back && action !== next);

  return (
    <main className="flex flex-col p-3 md:p-6">
      <p className="mb-3 px-2 text-sm text-rail-fg">
        {title}
        {pageId ? ` · ${pageId}` : ""}
      </p>
      <article className="mx-auto flex min-h-[70dvh] w-full max-w-3xl flex-col bg-paper px-6 pt-8 pb-6 text-ink md:px-10">
        <div className="min-h-0 flex-1 overflow-y-auto">
          {lines.length === 0 ? (
            <p className="text-muted">No lesson text on this page.</p>
          ) : (
            lines.map((line, index) => (
              <p key={`${pageId}-${index}`} className="mb-4 font-serif text-xl leading-relaxed">
                <Line line={line} word={helpWord} onWord={onWord} />
              </p>
            ))
          )}
        </div>
        <div className="sticky bottom-0 mt-4 flex shrink-0 items-center gap-3 border-t border-line bg-paper pt-4">
          <div className="w-28 shrink-0">{back ? <Action action={back} /> : null}</div>
          <div className="flex min-w-0 flex-1 flex-wrap justify-center gap-2">
            {rest.map((action, index) => (
              <Action key={`${action.label}-${index}`} action={action} />
            ))}
          </div>
          <div className="flex w-28 shrink-0 justify-end">{next ? <Action action={next} /> : null}</div>
        </div>
      </article>
    </main>
  );
}

function Line({ line, word, onWord }: { line: string; word?: string; onWord?: () => void }) {
  if (!word || !onWord) return line;
  const parts = line.split(new RegExp(`(\\b${word}\\b)`, "i"));
  return parts.map((part, index) =>
    part.toLowerCase() === word.toLowerCase() ? (
      <button
        key={index}
        type="button"
        className="bg-transparent p-0 font-serif text-xl text-ink underline"
        onClick={onWord}
      >
        {part}
      </button>
    ) : (
      <span key={index}>{part}</span>
    ),
  );
}

function Action({ action }: { action: { label: string; run: () => void } }) {
  return (
    <button type="button" className="min-h-11 bg-bar px-4 text-sm text-bar-fg" onClick={action.run}>
      {action.label}
    </button>
  );
}
